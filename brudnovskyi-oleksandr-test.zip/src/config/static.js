export const ACTIVE = 'Yes';
export const NOT_ACTIVE = 'No';
export const EDIT = 'Edit';
export const VIEW = 'View';
export const SAVE = 'Save';
export const REMOVE = 'Remove';

export const EMPLOYEE_LIST_TITLE = ['', '', 'Employee ID', 'Employee name', 'Employee active', 'Employee department', ''];