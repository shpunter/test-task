export const REMOVE = 'REMOVE';
export const MODAL_VIEW = 'MODAL_VIEW';
export const MODAL_EDIT = 'MODAL_EDIT';
export const MODAL_HIDE = 'MODAL_HIDE';
export const SAVE_USER = 'SAVE_USER';
export const SAVE_USERS_FROM_RESPONSE = 'SAVE_USERS_FROM_RESPONSE';
export const SAVE_SEARCH = 'SAVE_SEARCH';